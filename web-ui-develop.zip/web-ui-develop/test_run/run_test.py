# -*- coding:utf-8 *-
# 项目       :    pytest1 
# 文件       :    run_test.py
# 作者       :    zhangchen 
# 时间       :    2021/6/10  6:00 下午 
# IDE       :    PyCharm
import re

import pytest
import os

#定义启动项
class RunTest():
    def _runpytest(self):
        pass
#pytest启动
    @staticmethod
    def run_alltest():
        # # 执行pytest单元测试，生成 Allure 报告需要的数据存在 /temp 目录,使用--clean-alluredir 覆盖之前的json文件
        # pytest.main(['-s', '-q','--alluredir', './report','--clean-alluredir'])
        # # 执行命令 allure generate ./temp -o ./report --clean ，生成测试报告
        # # os.system(" allure generate ./report/result_allure -o ./report/result_html -c")

        pytest.main()
        os.system('allure generate ./report -o ./report/temp --clean')




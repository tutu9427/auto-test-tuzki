# -*- coding:utf-8 *-
# 项目       :    pytest1 
# 文件       :    webpage.py
# 作者       :    zhangchen 
# 时间       :    2021/6/8  5:30 下午 
# IDE       :    PyCharm
import time

from lib.init_data import get_data
from lib.func import think_time
import os
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

BASE_CONF = get_data(os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "config.ini"))['App']


class WebPage():
    #读取config.ini中的配置
    def __init__(self,d):
        self.d = d
        self.web = BASE_CONF['URL_NAME']
        self.time_out = BASE_CONF['WAIT_TIMEOUT']


class BasePage(WebPage):
    #初始化
    def __init__(self):
        self.driver = webdriver.Chrome()
        self.wait = WebDriverWait(self.driver,10)
        # self.driver.maximize_window()
        self.driver.set_window_size(1620,960)
        WebPage.__init__(self,self.driver)
        self.openURL()

    def openURL(self):
        #默认打开URL
        self.d.get(self.web)

    def close_browser(self):
        #关闭浏览器
        self.d.close()

#————————————————————————————————————封装公共方法——————————————————————————————————————————

    def by_id(self,id):
        self.d.find_element_by_id(id).click()

    def by_class(self,classname):
        self.d.find_element_by_class_name(classname).click()





#
# if __name__ == '__main__':
#     BasePage(driver=webdriver.Chrome())
# -*- coding:utf-8 *-
# 项目       :    web-ui 
# 文件       :    pageobject_page.py
# 作者       :    zc 
# 时间       :    2021/6/29  9:15 下午 
# IDE       :    PyCharm
from time import sleep

from poium import Page, Element, Elements
from selenium import webdriver


class sycamore(Page):
    input_name = Element(xpath='//*[@id="app"]/div/div[2]/div/div[1]/form/div[1]/div/div/input',describe='手机号')
    input_pass = Element(xpath='//*[@id="app"]/div/div[2]/div/div[1]/form/div[2]/div/div/input',describe='密码')
    button = Element(xpath='//*[@id="app"]/div/div[2]/div/div[1]/form/div[4]/div/button',describe='确认按钮')
    # results = Elements(xpath='//div/h3/a',describe='搜索结果')

def sycamore_login(driver):
    page = sycamore(driver)
    page.get('https://sj-test.360che.com/store/#/')
    page.input_name.send_keys('17600960626')
    page.input_pass.send_keys("z123456z")
    page.button.click()


if __name__ == '__main__':
    dr=webdriver.Chrome()
    sycamore_login(driver=dr)
    sleep(5)

# elem=page.results
# for e in elem:
#     print(e.text)


# dr.close()
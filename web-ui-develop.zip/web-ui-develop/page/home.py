# -*- coding:utf-8 *-
# 项目       :    pytest1 
# 文件       :    home.py
# 作者       :    zhangchen 
# 时间       :    2021/6/8  6:26 下午 
# IDE       :    PyCharm

from page.webpage import BasePage
from lib.func import think_time

#写自定义方法
class customMethod(BasePage):

    @think_time
    def search(self):
        self.d.find_element()
# -*- coding:utf-8 *-
# 项目       :    pytest1 
# 文件       :    loggers.py
# 作者       :    zhangchen 
# 时间       :    2021/6/8  5:10 下午 
# IDE       :    PyCharm

import os, time
import os.path
import socket
import logging
import logging.handlers

#log日志的配置封装
def singleton(cls, *args, **kw):
    instances = {}

    def _singleton():
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]

    return _singleton


# @singleton
class JFMlogging(object):
    def __init__(self):
        # host_name = socket.gethostname()
        # ip = socket.gethostbyname(host_name)
        log_path = 'logs'  # 日志存放目录
        if not os.path.exists(log_path):
            os.mkdir(log_path)
        log_file = os.path.join(log_path, "{}.log".format(time.strftime("%Y%m%d")))

        self.logger = logging.getLogger()
        self.logger.setLevel(logging.INFO)

        self.logging_msg_format = '[%(asctime)s] [%(levelname)s] [%(module)s.py-line:%(lineno)d] %(message)s'
        self.formater = logging.Formatter(self.logging_msg_format)

        self.fileHandler = logging.FileHandler(log_file, mode='a', encoding="UTF-8")
        self.fileHandler.setFormatter(self.formater)
        self.fileHandler.setLevel(logging.INFO)

        self.console = logging.StreamHandler()
        self.console.setLevel(logging.INFO)
        self.console.setFormatter(self.formater)

        self.logger.addHandler(self.fileHandler)
        self.logger.addHandler(self.console)

    # def getloger(self):
    #     return self.logger


log = JFMlogging().logger
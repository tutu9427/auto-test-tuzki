# -*- coding:utf-8 *-
# 项目       :    all_auto 
# 文件       :    excel_red.py
# 作者       :    zhangchen 
# 时间       :    2021/3/3  10:36 上午 
# IDE       :    PyCharm
import os
from  openpyxl import load_workbook

class Handle_excel:
    def __init__(self,excel_path,sheet):
        self.wb = load_workbook(excel_path)
        self.sh = self.wb[sheet]

    # 获取所有的数据，与第一行进行拼接，字典形式
    def read_all_data(self):
        #获取第一行数据，作为key
        title = self.read_title()
        # 测试用例集合
        case_datas = []
        # 获取每一行数据，与表头进行拼接，形成一个测试用例数据
        for item in self.all_rows[1:]: # item 每一行的所有对象，是个元组
            value = []
            for cell in item:
                value.append(cell.value)
            case = dict(zip(title, value))
            case_datas.append(case)
        return case_datas

    # 获取第一行数据，作为key
    def read_title(self):
        # 获取所有的行对象
        self.get_rows_obj()
        # key 集合
        title = []
        for item in self.all_rows[0]:
            title.append(item.value)
        return title


    # 获取所有行的对象
    def get_rows_obj(self):
      self.all_rows = list(self.sh.rows)

    # 将数据写入excel单元格中
    def weite_data(self,row,col,value):
        self.sh.cell(row,col).value=value

    # 将数据保存到excel单元格中
    def save_data(self,excel_path):
        self.wb.save(excel_path)

    #  获取excel路径
    def file_name(file_dir):
        for root ,dirs,files in os.walk(file_dir):
            print('当前目录',root)
            print('所有子目录',dirs)
            print('文件',files)

if __name__ == '__main__':
    file = '/Users/a1234/web-ui/data_case/cases.xlsx'
    cur = os.path.dirname(os.path.abspath(file))
    excel_path = os.path.join(cur,'cases.xlsx')
    print(excel_path)
    he = Handle_excel(excel_path,"sheet1")
    cases = he.read_all_data()
    print(cases)
    print(list(cases[0].values()))#获取values

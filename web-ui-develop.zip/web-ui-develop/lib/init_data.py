# -*- coding:utf-8 *-
# 项目       :    pytest1 
# 文件       :    init_data.py
# 作者       :    zhangchen 
# 时间       :    2021/6/8  5:50 下午 
# IDE       :    PyCharm

from lib.read_data import data
import os

#对读取测试数据及ini文件的配置
BASE_PATH = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

def get_data(file_name):

    data_file_path = os.path.join(BASE_PATH, "data_case", file_name)
    if '.yml' in file_name:
        test_data = data.load_yaml(data_file_path)
    if '.json' in file_name:
        test_data = data.load_json(data_file_path)
    if '.ini' in file_name:
        test_data = data.load_ini(data_file_path)

    return test_data
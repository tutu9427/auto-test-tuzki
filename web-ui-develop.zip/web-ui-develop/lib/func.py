# -*- coding:utf-8 *-
# 项目       :    pytest1 
# 文件       :    func.py
# 作者       :    zhangchen 
# 时间       :    2021/6/8  5:31 下午 
# IDE       :    PyCharm

import time

#等待时间装饰器
def think_time(func):
    def thinktime(*args,**kwargs):
        time.sleep(1)
        return func(*args,**kwargs)
    return thinktime



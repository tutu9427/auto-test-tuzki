# -*- coding:utf-8 *-
# 项目       :    pytest1 
# 文件       :    run.py
# 作者       :    zhangchen 
# 时间       :    2021/6/10  6:02 下午 
# IDE       :    PyCharm

from test_run import run_test
from Update_driver import Check_driver

#入口文件
class startest(run_test.RunTest,Check_driver.Check_Driver):
    import time
    test_data = time

# class sterdown(Check_driver.Check_Driver):



if __name__ == '__main__':
    startest.Run_download_driver()#检测chromedriver版本，不需要注释即可
    # startest.run_alltest()
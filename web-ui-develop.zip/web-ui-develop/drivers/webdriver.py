# -*- coding:utf-8 *-
# 项目       :    pytest1 
# 文件       :    webdriver.py
# 作者       :    zhangchen 
# 时间       :    2021/6/8  5:03 下午 
# IDE       :    PyCharm
from selenium import webdriver

#封装Chrome启动的driver
def webdrivers():
    d = webdriver.Chrome()
    return d

webdrivers()
# -*- coding:utf-8 *-
# 项目       :    pytest1 
# 文件       :    connftest.py
# 作者       :    zhangchen 
# 时间       :    2021/6/8  4:52 下午 
# IDE       :    PyCharm

from selenium import webdriver
import pytest
import time
import drivers.webdriver
from lib.loggers import log

#初始化全局 driver
@pytest.fixture(scope='session',autouse=True)
def driver():
    try:
        global driver
        driver =drivers.webdriver.webdrivers()
        return driver
    except Exception as e:
        log.info('初始化webdriver{}'.format(e))

#初始全局关闭
@pytest.fixture(scope='session',autouse=True)
def driver_close():
    yield driver
    driver.quit()
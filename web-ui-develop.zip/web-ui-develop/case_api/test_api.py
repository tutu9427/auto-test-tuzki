# -*- coding:utf-8 *-
# 项目       :    web-ui 
# 文件       :    test_api.py
# 作者       :    zc 
# 时间       :    2021/6/23  11:02 上午 
# IDE       :    PyCharm

import time
import allure
import pytest
import requests
import json
from lib.init_data import get_data

# base_data=get_data("api_demo.yml")


class Test_case():
    @pytest.fixture(scope='module')
    @allure.feature('登录')
    def test_login(self):
        url = "https://shop-api-yfb.360che.com/store/login/pwd_login"
        parameter = {
            "mobile": 17600960626,
            "password": "Ny4Ma00CMNXuHwmriJSKc0/TDwBrjDSOWfcmpgePDaV8rRziLpJMs/xoGR7r9N3H8rs+0y7YtxEL3qcSb6eQ/qI/shPd7c/z80evCKjPhfsnLYfvAifFQg+gSx5TXvKUzQNtzpDCLaNiKT2w0Yed48WD/yGx+u+voUCL+f1oJjk="
            , "checkType": True}
        header = {
            'Content-Type': 'application/json;charset=UTF-8',
            "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.106 Safari/537.36",

        }
        s = requests.Session()
        res=s.post(url, data=json.dumps(parameter), headers=header)
        # yield
        yield res.json().get("token")
        # print(res.json())

    @allure.feature('店铺详情')
    def test_1(self,test_login):

        headers={
            "token":test_login
        }
        url='https://shop-api-yfb.360che.com/store/manage_shop/get_shop_url/3/3'
        res=requests.get(url,headers=headers)
        # print(res,1111,res.status_code)
        print('测试结果',res.status_code)
        assert res.status_code == 200



    @allure.feature('店铺搜索')
    def test_2(self):
        headers = {
            "Content-Type": "application/json"
        }
        url ='https://shop-api-yfb.360che.com/store/home_page/create_browse/3'
        res = requests.get(url,headers=headers).json()
        print('测试结果',res)
        assert res ==[]

    @allure.feature('退款列表筛选')
    def test_3(self,test_login):
        headers ={
            "Content-Type":"application/x-www-form-urlencoded",
            "token":test_login
        }
        url = "http://shop-api-qa.360che.com/store/manager_refund/search_refund_list"
        data ={
            "user_id": "4",
            "shop_id": "3",
            "page": "1",
            "page_size": "",
            "refund_type": "0",
            "refund_order_status": "0",
            "delivery_status": "0"
        }
        res = requests.post(url,headers=headers,data=data)
        # print(res.json())
        print('测试结果',res.status_code)
        assert res.status_code == 2001


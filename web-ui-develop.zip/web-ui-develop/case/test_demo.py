# -*- coding:utf-8 *-
# 项目       :    pytest1 
# 文件       :    test.py
# 作者       :    zhangchen 
# 时间       :    2021/6/8  4:27 下午 
# IDE       :    PyCharm
import time
import allure
import pytest

from page.webpage import BasePage
from lib.init_data import get_data




base_data=get_data("demo.yml")

@pytest.mark.usefixtures()
class Test_case():

    @pytest.mark.parametrize("expected",base_data['test_id'])
    @allure.feature('打开首页')
    def test_1(self,expected):
        d =BasePage()
        try:
            d.by_id(expected)
            assert 1==1
        finally:
            time.sleep(4)
            d.close_browser()



# if __name__ =="__main__":
#
#     # # 执行pytest单元测试，生成 Allure 报告需要的数据存在 /temp 目录,使用--clean-alluredir 覆盖之前的json文件
#     # pytest.main(['-s', '-q','--alluredir', './report','--clean-alluredir'])
#     # # 执行命令 allure generate ./temp -o ./report --clean ，生成测试报告
#     # # os.system(" allure generate ./report/result_allure -o ./report/result_html -c")
#     # os.system('allure generate ./report -o ./report/temp --clean')
#     # 执行pytest单元测试，生成 Allure 报告需要的数据存在 /temp 目录,使用--clean-alluredir 覆盖之前的json文件
#     pytest.main(['-s', '-q','test_demo.py', '--alluredir', './report', '--clean-alluredir'])
#     # 执行命令 allure generate ./temp -o ./report --clean ，生成测试报告
#     # os.system(" allure generate ./report/result_allure -o ./report/result_html -c")
#     os.system('allure generate ./report -o ./report/temp --clean')
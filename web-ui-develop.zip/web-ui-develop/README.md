# Web-UI

#### 介绍
pytest+allure 自动化框架

#### 软件架构
pytest==5.4.2
selenium==3.141.0
allure_python_commons==2.8.29
PyYAML==5.4.1
python==3.6.0



#### 安装教程

使用 pip install -r requirements.txt



#### 使用说明

目录结构：
case==case文件目录
data_case==case参数
drivers==webdriver存放
lib==定义log、读取yml、时间装饰器
logs==存放log文件
page==功能方法封装
report==报告存放
test_run==定义启动类，启动使用的命令
config.ini==配置文件-根据不同的文件名运行web或者api测试
connftest.py==全局共享使用
run.py==入口文件

### 备注
个人工作使用，不喜欢请轻喷

# -*- coding:utf-8 *-
# 项目       :    web-ui 
# 文件       :    Download.py
# 作者       :    zhangchen 
# 时间       :    2021/6/11  2:12 下午 
# IDE       :    PyCharm

import requests
import zipfile


class Download_dev():

    def download_driver(self, download_url):
        '''下载文件'''
        file = requests.get(download_url)
        with open("chromedriver.zip", 'wb') as zip_file:  # 保存文件到脚本所在目录
            zip_file.write(file.content)
            print('下载成功')


    def unzip_driver(self,path):
        '''解压Chromedriver压缩包到指定目录'''
        f = zipfile.ZipFile("chromedriver.zip", 'r')
        for file in f.namelist():
            f.extract(file, path)